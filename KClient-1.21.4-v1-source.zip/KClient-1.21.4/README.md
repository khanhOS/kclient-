# KClient 1.0.0 (v1 / Free) - Minecraft 1.21.4 Fabric

Lightweight utility client: 30 modules, translucent purple ClickGUI (Right Shift), per-module settings panel (gear icon), keybinds, local config.
Only dependency: Fabric API 0.119.4+1.21.4. Output jar: `kclient-1.0.0.jar`.

**Status:** syntax-checked only; not compiled against Minecraft or boot-tested here. See PROJECT_STATUS.txt.
Intended for use on servers you own/administer.

## Target compatibility

- Minecraft Java Edition: **1.21.4**
- Java: **21**
- Fabric Loader: **0.16.9** or newer
- Fabric API: **0.119.4+1.21.4**
- Yarn mappings: **1.21.4+build.8**
- Fabric Loom: **1.9.2**
- Expected Gradle: **8.12**

These versions are based on the uploaded `meteor-client-1.21.4-42.jar` metadata and publicly published Fabric artifacts. The uploaded JAR was inspected for metadata only; its code and resources are not copied into this project.

## Included in this prototype

- Right Shift opens the translucent ClickGUI; Escape closes it.
- Search field supports typing and Backspace.
- Category sidebar and responsive module cards.
- Toggle switches for modules.
- FPS HUD, XYZ coordinates HUD, enabled-module ArrayList HUD, Auto Sprint, and World Time HUD.
- Module enabled states saved locally in `.minecraft/config/kclient.properties`.
- No account login, token collection, remote activation service, payments, or Pro unlock implementation.

Combat and Player categories are intentionally empty placeholders for future independently written modules. This is a source starter, not a full feature-for-feature Meteor replacement.

## Build locally

Install a 64-bit Java 21 JDK and Gradle 8.12, then run from this directory:

```bat
gradle build
```

The remapped mod JAR should be produced in `build/libs/`. Install Fabric Loader for Minecraft 1.21.4 and put the built JAR in that instance's `mods` folder. Do not place a development JAR (`-dev`) in a regular game instance.

## Build with GitHub Actions

Upload/unzip this project into a GitHub repository. The included workflow builds with Java 21 and Gradle 8.12, then uploads JARs from `build/libs/` as a workflow artifact. The build needs network access to download Gradle and Minecraft/Fabric dependencies.

## Low-memory notes

`gradle.properties` limits Gradle heap to 1 GiB and parallel workers to two. Gradle's initial dependency download/build may still take time and use disk space.

## License and Meteor reference

The uploaded Meteor JAR declares GPL-3.0. This project is a clean, independent implementation and does not bundle Meteor code. If you later fork or copy GPL-licensed code, review the license obligations carefully before distributing a closed-source/proprietary Pro edition. GPL permits commercial distribution but has source-sharing and same-license obligations for covered derivative works.

## Verification status

This archive is a **source prototype**. It has not been compiled or launched in Minecraft in this environment because the environment cannot resolve external hosts to download Gradle and dependencies. Run the build workflow or build locally and inspect the result before distributing it.
