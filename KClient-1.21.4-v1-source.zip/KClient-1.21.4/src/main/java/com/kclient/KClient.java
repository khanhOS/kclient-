package com.kclient;

import com.kclient.config.ConfigManager;
import com.kclient.gui.ClickGuiScreen;
import com.kclient.module.ModuleManager;
import com.kclient.module.impl.MiscModules;
import com.kclient.util.Projector;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.IdentifiedLayer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class KClient implements ClientModInitializer {
    public static final String MOD_ID = "kclient";
    public static ModuleManager MODULES;
    public static ConfigManager CONFIG;
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        MODULES = new ModuleManager();
        CONFIG = new ConfigManager();
        CONFIG.load(MODULES);

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kclient.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.kclient"));

        ClientTickEvents.START_CLIENT_TICK.register(MODULES::tick);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) client.setScreen(new ClickGuiScreen());
        });

        // Capture the real world projection matrix once per frame for the 2D ESP overlay.
        WorldRenderEvents.END.register(ctx -> Projector.capture(ctx.projectionMatrix()));

        HudLayerRegistrationCallback.EVENT.register(layered -> layered.attachLayerAfter(
                IdentifiedLayer.MISC_OVERLAYS,
                Identifier.of(MOD_ID, "kclient_hud"),
                (context, tickCounter) -> MODULES.renderHud(context, tickCounter.getTickDelta(false))));

        MiscModules.AutoGG autoGG = MODULES.get(MiscModules.AutoGG.class);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) autoGG.onMessage(message.getString());
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> CONFIG.save(MODULES));
    }
}
