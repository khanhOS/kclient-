package com.kclient.gui;

import com.kclient.KClient;
import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.setting.BoolSetting;
import com.kclient.setting.EnumSetting;
import com.kclient.setting.NumSetting;
import com.kclient.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ClickGuiScreen extends Screen {
    private static final int PURPLE = 0xFF9B72FF;
    private static final int TEXT = 0xFFE5E0FF;
    private static final int MUTED = 0xFFAAA5CE;
    private static final int PANEL = 0xD00A0B16;
    private static final int BORDER = 0x665C5685;
    private static final int ROW_H = 24;
    private static final int SIDE_X = 14, SIDE_Y = 14, SIDE_W = 130;

    private Category selected = Category.ALL;
    private String search = "";
    private boolean searchFocused;
    private int workScroll, workMax;

    private Module settingsModule;
    private int settingsScroll, settingsMax;
    private boolean listeningBind;
    private Setting dragging;
    private Rect dragTrack;

    private final List<Hit<Module>> toggleHits = new ArrayList<>();
    private final List<Hit<Module>> gearHits = new ArrayList<>();
    private final List<Hit<Setting>> settingHits = new ArrayList<>();
    private final Map<Category, Rect> categoryHits = new EnumMap<>(Category.class);
    private Rect searchRect, workClip, panelRect, titleRect, bindRect, saveRect, resetRect;

    public ClickGuiScreen() { super(Text.literal("KClient")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    protected void applyBlur() { /* keep the world sharp; GUI is translucent only */ }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        toggleHits.clear(); gearHits.clear(); settingHits.clear(); categoryHits.clear();
        bindRect = null; saveRect = null; resetRect = null; titleRect = null;
        c.fill(0, 0, width, height, 0x30040310);
        drawSidebar(c, mx, my);
        drawWorkspace(c, mx, my);
        if (settingsModule != null) drawSettings(c, mx, my); else panelRect = null;
    }

    // ------------------------------------------------------------------ sidebar
    private void drawSidebar(DrawContext c, int mx, int my) {
        int h = Math.max(200, height - SIDE_Y * 2);
        panel(c, SIDE_X, SIDE_Y, SIDE_W, h);
        c.fill(SIDE_X + 1, SIDE_Y + 1, SIDE_X + SIDE_W - 1, SIDE_Y + 46, 0x9A28194A);
        c.drawTextWithShadow(textRenderer, "\u25C6 KClient", SIDE_X + 10, SIDE_Y + 11, PURPLE);
        c.drawTextWithShadow(textRenderer, "Free \u2022 Pro", SIDE_X + 10, SIDE_Y + 27, MUTED);
        int y = SIDE_Y + 54;
        for (Category cat : Category.values()) {
            if (cat == Category.ALL) continue;
            Rect r = new Rect(SIDE_X + 6, y, SIDE_W - 12, 22);
            categoryHits.put(cat, r);
            boolean active = selected == cat;
            if (active) c.fill(r.x, r.y, r.x + r.w, r.y + r.h, 0xC44B2AA0);
            else if (r.contains(mx, my)) c.fill(r.x, r.y, r.x + r.w, r.y + r.h, 0x553C355F);
            c.drawTextWithShadow(textRenderer, glyph(cat) + "  " + cat.displayName(), r.x + 8, r.y + 7, active ? 0xFFFFFFFF : TEXT);
            y += 26;
        }
        c.fill(SIDE_X + 10, SIDE_Y + h - 34, SIDE_X + SIDE_W - 10, SIDE_Y + h - 33, BORDER);
        c.drawTextWithShadow(textRenderer, "MC 1.21.4", SIDE_X + 10, SIDE_Y + h - 26, MUTED);
        c.drawTextWithShadow(textRenderer, "R-Shift \u2022 Esc", SIDE_X + 10, SIDE_Y + h - 14, MUTED);
    }

    private static String glyph(Category c) {
        return switch (c) {
            case COMBAT -> "\u2694"; case MOVEMENT -> "\u2197"; case RENDER -> "\u25C9";
            case PLAYER -> "\u2659"; case MISC -> "\u2699"; case HUD -> "\u25A3"; case CONFIG -> "\u2630"; default -> "\u25C6";
        };
    }

    // ------------------------------------------------------------------ workspace
    private void drawWorkspace(DrawContext c, int mx, int my) {
        int x = SIDE_X + SIDE_W + 10, w = Math.max(160, width - x - 14), y = SIDE_Y;
        panel(c, x, y, w, 30);
        searchRect = new Rect(x + 6, y + 5, w - 80, 20);
        c.fill(searchRect.x, searchRect.y, searchRect.x + searchRect.w, searchRect.y + searchRect.h, searchFocused ? 0xD11A1B30 : 0xA7121322);
        c.drawTextWithShadow(textRenderer, search.isEmpty() ? "\u2315  Tìm module..." : "\u2315  " + search + (searchFocused ? "_" : ""),
                searchRect.x + 6, searchRect.y + 6, search.isEmpty() ? MUTED : TEXT);
        String count = KClient.MODULES.enabledModules().size() + " bật";
        c.drawTextWithShadow(textRenderer, count, x + w - textRenderer.getWidth(count) - 8, y + 11, PURPLE);

        int topY = y + 36;
        workClip = new Rect(x, topY, w, height - topY - 8);
        if (selected == Category.CONFIG) { drawConfig(c, x, topY, w, mx, my); return; }

        List<Module> visible = KClient.MODULES.find(search, selected);
        if (visible.isEmpty()) {
            panel(c, x, topY, w, 40);
            c.drawTextWithShadow(textRenderer, "Không tìm thấy module.", x + 12, topY + 15, MUTED);
            return;
        }
        Map<Category, List<Module>> groups = new EnumMap<>(Category.class);
        for (Module m : visible) groups.computeIfAbsent(m.category(), k -> new ArrayList<>()).add(m);

        int columns = w >= 700 ? 3 : w >= 420 ? 2 : 1, gap = 8;
        int cardW = (w - gap * (columns - 1)) / columns;
        int[] colY = new int[columns];
        for (int i = 0; i < columns; i++) colY[i] = topY - workScroll;

        c.enableScissor(workClip.x, workClip.y, workClip.x + workClip.w, workClip.y + workClip.h);
        for (Map.Entry<Category, List<Module>> e : groups.entrySet()) {
            int col = 0;
            for (int i = 1; i < columns; i++) if (colY[i] < colY[col]) col = i;
            int cx = x + col * (cardW + gap), cy = colY[col];
            int ch = 26 + e.getValue().size() * ROW_H + 4;
            panel(c, cx, cy, cardW, ch);
            c.drawTextWithShadow(textRenderer, glyph(e.getKey()) + "  " + e.getKey().displayName(), cx + 10, cy + 9, TEXT);
            c.fill(cx + 8, cy + 22, cx + cardW - 8, cy + 23, BORDER);
            int ry = cy + 26;
            for (Module m : e.getValue()) {
                Rect row = new Rect(cx + 4, ry, cardW - 8, ROW_H);
                if (row.contains(mx, my) && my >= workClip.y) c.fill(row.x, row.y, row.x + row.w, row.y + row.h, 0x423B315F);
                boolean on = m.isEnabled();
                c.drawTextWithShadow(textRenderer, m.name(), cx + 10, ry + 8, on ? 0xFFFFFFFF : MUTED);
                int tx = cx + cardW - 52, ty = ry + 6;
                c.fill(tx, ty, tx + 26, ty + 12, on ? 0xFF743FE0 : 0xFF343449);
                int kx = on ? tx + 15 : tx + 2;
                c.fill(kx, ty + 2, kx + 9, ty + 10, on ? 0xFFFFFFFF : 0xFFB0AEC9);
                Rect gear = new Rect(cx + cardW - 22, ry + 4, 16, 16);
                c.drawTextWithShadow(textRenderer, "\u2699", gear.x + 3, gear.y + 4, settingsModule == m ? PURPLE : MUTED);
                toggleHits.add(new Hit<>(new Rect(row.x, row.y, row.w - 26, row.h), m));
                gearHits.add(new Hit<>(gear, m));
                ry += ROW_H;
            }
            colY[col] = cy + ch + gap;
        }
        c.disableScissor();
        int bottom = 0;
        for (int v : colY) bottom = Math.max(bottom, v);
        workMax = Math.max(0, bottom + workScroll - (topY + workClip.h));
        workScroll = Math.min(workScroll, workMax);
    }

    private void drawConfig(DrawContext c, int x, int y, int w, int mx, int my) {
        panel(c, x, y, w, 110);
        c.drawTextWithShadow(textRenderer, "Cấu hình", x + 12, y + 10, TEXT);
        c.drawTextWithShadow(textRenderer, "Tự động lưu tại .minecraft/config/kclient.properties", x + 12, y + 28, MUTED);
        saveRect = new Rect(x + 12, y + 50, 90, 20);
        resetRect = new Rect(x + 112, y + 50, 130, 20);
        c.fill(saveRect.x, saveRect.y, saveRect.x + saveRect.w, saveRect.y + saveRect.h, 0xFF4B2AA0);
        c.drawTextWithShadow(textRenderer, "Lưu ngay", saveRect.x + 18, saveRect.y + 6, 0xFFFFFFFF);
        c.fill(resetRect.x, resetRect.y, resetRect.x + resetRect.w, resetRect.y + resetRect.h, 0xFF343449);
        c.drawTextWithShadow(textRenderer, "Tắt tất cả module", resetRect.x + 10, resetRect.y + 6, TEXT);
        c.drawTextWithShadow(textRenderer, "Phím mở GUI: Right Shift (đổi trong Điều khiển)", x + 12, y + 84, MUTED);
    }

    // ------------------------------------------------------------------ settings panel
    private void drawSettings(DrawContext c, int mx, int my) {
        Module m = settingsModule;
        int pw = Math.min(230, width - 20);
        int px = width - pw - 14, py = 52;
        int rows = m.settings().size() + 1;
        int ph = Math.min(height - py - 12, 44 + rows * 18);
        panelRect = new Rect(px, py, pw, ph);
        panel(c, px, py, pw, ph);
        titleRect = new Rect(px, py, pw, 16);
        c.fill(px, py, px + pw, py + 16, 0xFF7A3CF0);
        c.drawTextWithShadow(textRenderer, m.name(), px + (pw - textRenderer.getWidth(m.name())) / 2, py + 4, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, "\u25BE", px + pw - 12, py + 4, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(m.description(), pw - 12), px + 6, py + 20, MUTED);

        int clipTop = py + 32, clipBottom = py + ph - 2;
        c.enableScissor(px, clipTop, px + pw, clipBottom);
        int y = clipTop - settingsScroll;
        for (Setting s : m.settings()) {
            Rect row = new Rect(px + 4, y, pw - 8, 16);
            if (y + 16 > clipTop && y < clipBottom) {
                c.drawTextWithShadow(textRenderer, s.name, px + 8, y + 4, TEXT);
                if (s instanceof BoolSetting b) {
                    int bx = px + pw - 22;
                    c.fill(bx, y + 3, bx + 10, y + 13, 0xFF343449);
                    if (b.get()) c.fill(bx + 1, y + 4, bx + 9, y + 12, 0xFF9B4DFF);
                } else if (s instanceof NumSetting n) {
                    int tx = px + 92, tw = pw - 92 - 40;
                    Rect track = new Rect(tx, y + 4, tw, 8);
                    c.fill(tx, y + 7, tx + tw, y + 9, 0xFF343449);
                    int kx = tx + (int) (tw * n.ratio());
                    c.fill(tx, y + 7, kx, y + 9, 0xFF9B72FF);
                    c.fill(kx - 2, y + 4, kx + 2, y + 12, 0xFFB79CFF);
                    String v = n.display();
                    c.drawTextWithShadow(textRenderer, v, px + pw - 8 - textRenderer.getWidth(v), y + 4, TEXT);
                    settingHits.add(new Hit<>(track, s));
                    y += 18;
                    continue;
                } else if (s instanceof EnumSetting e) {
                    String v = e.display();
                    c.drawTextWithShadow(textRenderer, v, px + pw - 8 - textRenderer.getWidth(v), y + 4, 0xFFB79CFF);
                }
                settingHits.add(new Hit<>(row, s));
            }
            y += 18;
        }
        // bind row
        if (y + 16 > clipTop && y < clipBottom) {
            bindRect = new Rect(px + 4, y, pw - 8, 16);
            String key = m.bind() < 0 ? "Không" : InputUtil.fromKeyCode(m.bind(), 0).getLocalizedText().getString();
            c.drawTextWithShadow(textRenderer, "Phím: " + (listeningBind ? "nhấn một phím (Esc = xóa)" : key), px + 8, y + 4, listeningBind ? PURPLE : TEXT);
        }
        c.disableScissor();
        settingsMax = Math.max(0, rows * 18 - (clipBottom - clipTop));
        settingsScroll = Math.min(settingsScroll, settingsMax);
    }

    // ------------------------------------------------------------------ input
    @Override
    public boolean mouseClicked(double dx, double dy, int button) {
        int mx = (int) dx, my = (int) dy;
        searchFocused = searchRect != null && searchRect.contains(mx, my);

        if (settingsModule != null && panelRect != null && panelRect.contains(mx, my)) {
            if (titleRect != null && titleRect.contains(mx, my)) { settingsModule = null; listeningBind = false; return true; }
            if (bindRect != null && bindRect.contains(mx, my)) { listeningBind = true; return true; }
            for (Hit<Setting> h : settingHits) {
                if (!h.rect.contains(mx, my)) continue;
                Setting s = h.value;
                if (s instanceof BoolSetting b) b.toggle();
                else if (s instanceof EnumSetting e) e.cycle(button == 1 ? -1 : 1);
                else if (s instanceof NumSetting n) { dragging = n; dragTrack = h.rect; n.setRatio((mx - h.rect.x) / (double) h.rect.w); }
                KClient.CONFIG.save(KClient.MODULES);
                return true;
            }
            return true;
        }

        for (Map.Entry<Category, Rect> e : categoryHits.entrySet()) {
            if (e.getValue().contains(mx, my)) {
                selected = selected == e.getKey() ? Category.ALL : e.getKey();
                workScroll = 0;
                return true;
            }
        }
        if (saveRect != null && saveRect.contains(mx, my)) { KClient.CONFIG.save(KClient.MODULES); return true; }
        if (resetRect != null && resetRect.contains(mx, my)) {
            for (Module m : KClient.MODULES.all()) m.setEnabled(false);
            KClient.CONFIG.save(KClient.MODULES);
            return true;
        }
        if (workClip != null && workClip.contains(mx, my)) {
            for (Hit<Module> h : gearHits) {
                if (h.rect.contains(mx, my)) {
                    settingsModule = settingsModule == h.value ? null : h.value;
                    settingsScroll = 0;
                    listeningBind = false;
                    return true;
                }
            }
            for (Hit<Module> h : toggleHits) {
                if (h.rect.contains(mx, my)) {
                    h.value.toggle();
                    KClient.CONFIG.save(KClient.MODULES);
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging instanceof NumSetting n && dragTrack != null) {
            n.setRatio((mx - dragTrack.x) / (double) dragTrack.w);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) { dragging = null; dragTrack = null; KClient.CONFIG.save(KClient.MODULES); }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (panelRect != null && panelRect.contains((int) mx, (int) my)) {
            settingsScroll = Math.max(0, Math.min(settingsMax, settingsScroll - (int) (v * 14)));
        } else {
            workScroll = Math.max(0, Math.min(workMax, workScroll - (int) (v * 20)));
        }
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && !Character.isISOControl(chr)) { search += chr; workScroll = 0; return true; }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (listeningBind && settingsModule != null) {
            settingsModule.setBind(key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE ? -1 : key);
            listeningBind = false;
            KClient.CONFIG.save(KClient.MODULES);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (searchFocused) { searchFocused = false; return true; }
            if (settingsModule != null) { settingsModule = null; return true; }
            close();
            return true;
        }
        if (searchFocused && key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        if (searchFocused && key == GLFW.GLFW_KEY_ENTER) { searchFocused = false; return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void close() {
        KClient.CONFIG.save(KClient.MODULES);
        if (client != null) client.setScreen(null);
    }

    private static void panel(DrawContext c, int x, int y, int w, int h) {
        c.fill(x, y, x + w, y + h, PANEL);
        c.fill(x, y, x + w, y + 1, BORDER);
        c.fill(x, y + h - 1, x + w, y + h, BORDER);
        c.fill(x, y, x + 1, y + h, BORDER);
        c.fill(x + w - 1, y, x + w, y + h, BORDER);
    }

    private record Rect(int x, int y, int w, int h) {
        boolean contains(int px, int py) { return px >= x && py >= y && px < x + w && py < y + h; }
    }

    private record Hit<T>(Rect rect, T value) { }
}
