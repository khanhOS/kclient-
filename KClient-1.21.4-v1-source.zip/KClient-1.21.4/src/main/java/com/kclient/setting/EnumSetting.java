package com.kclient.setting;

import java.util.Map;

public final class EnumSetting extends Setting {
    public final String[] options;
    private int index;

    public EnumSetting(String name, String def, String... options) {
        super(name);
        this.options = options;
        for (int i = 0; i < options.length; i++) if (options[i].equals(def)) index = i;
    }

    private static final Map<String, String> VI = Map.ofEntries(
            Map.entry("Both", "Cả hai"), Map.entry("Sword", "Kiếm"), Map.entry("Axe", "Rìu"), Map.entry("Any", "Bất kỳ"),
            Map.entry("Always", "Luôn luôn"), Map.entry("On Hit", "Khi đánh"), Map.entry("None", "Không"),
            Map.entry("LowestHealth", "Máu thấp nhất"), Map.entry("HighestHealth", "Máu cao nhất"),
            Map.entry("Closest", "Gần nhất"), Map.entry("Bottom", "Dưới"), Map.entry("Center", "Giữa"));

    public String display() { return VI.getOrDefault(options[index], options[index]); }

    public String get() { return options[index]; }
    public boolean is(String option) { return options[index].equals(option); }
    public void cycle(int dir) { index = Math.floorMod(index + dir, options.length); }

    @Override public String serialize() { return options[index]; }
    @Override public void deserialize(String s) {
        for (int i = 0; i < options.length; i++) if (options[i].equals(s)) index = i;
    }
}
