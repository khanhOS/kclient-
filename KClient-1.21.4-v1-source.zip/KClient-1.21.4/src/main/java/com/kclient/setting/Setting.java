package com.kclient.setting;

import java.text.Normalizer;

public abstract class Setting {
    public final String id;
    public final String name;

    protected Setting(String name) {
        this.name = name;
        this.id = idOf(name);
    }

    static String idOf(String n) {
        String s = Normalizer.normalize(n.replace('đ', 'd').replace('Đ', 'D'), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return s.toLowerCase().replaceAll("[^a-z0-9]", "");
    }

    public abstract String serialize();
    public abstract void deserialize(String value);
}
