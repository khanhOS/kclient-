package com.kclient.setting;

import java.util.Locale;

public final class NumSetting extends Setting {
    public final double min, max, step;
    private double value;

    public NumSetting(String name, double def, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = clamp(def);
    }

    private double clamp(double v) { return Math.max(min, Math.min(max, v)); }

    public double value() { return value; }
    public int intValue() { return (int) Math.round(value); }
    public float floatValue() { return (float) value; }
    public double ratio() { return max == min ? 0 : (value - min) / (max - min); }

    public void setRatio(double r) {
        double v = min + Math.max(0, Math.min(1, r)) * (max - min);
        if (step > 0) v = Math.round((v - min) / step) * step + min;
        value = clamp(v);
    }

    public String display() {
        return step >= 1 ? Long.toString(Math.round(value)) : String.format(Locale.ROOT, "%.1f", value);
    }

    @Override public String serialize() { return Double.toString(value); }
    @Override public void deserialize(String s) {
        try { value = clamp(Double.parseDouble(s)); } catch (NumberFormatException ignored) { }
    }
}
