package com.kclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

/** Projects world positions to scaled GUI coordinates using the real world projection matrix (no GL state needed). */
public final class Projector {
    private static final Matrix4f PROJ = new Matrix4f();
    private static final Quaternionf INV = new Quaternionf();
    private static final Vector3f V = new Vector3f();
    private static final Vector4f V4 = new Vector4f();
    private static final double[] TMP = new double[2];
    private static boolean ready;
    private static double camX, camY, camZ;
    private static int sw, sh;

    private Projector() { }

    public static void capture(Matrix4f projection) {
        PROJ.set(projection);
        ready = true;
    }

    public static void beginFrame(MinecraftClient mc) {
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d p = cam.getPos();
        camX = p.x; camY = p.y; camZ = p.z;
        INV.set(cam.getRotation()).conjugate();
        sw = mc.getWindow().getScaledWidth();
        sh = mc.getWindow().getScaledHeight();
    }

    public static boolean project(double x, double y, double z, double[] out) {
        if (!ready) return false;
        V.set((float) (x - camX), (float) (y - camY), (float) (z - camZ));
        INV.transform(V);
        V4.set(V.x, V.y, V.z, 1f);
        PROJ.transform(V4);
        if (V4.w <= 0.05f) return false;
        float nx = V4.x / V4.w, ny = V4.y / V4.w;
        out[0] = (nx * 0.5 + 0.5) * sw;
        out[1] = (0.5 - ny * 0.5) * sh;
        return true;
    }

    /** Screen rectangle {minX, minY, maxX, maxY} around a world box; false if any corner is behind the camera. */
    public static boolean box(Box b, double[] rect) {
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            if (!project(x, y, z, TMP)) return false;
            minX = Math.min(minX, TMP[0]); maxX = Math.max(maxX, TMP[0]);
            minY = Math.min(minY, TMP[1]); maxY = Math.max(maxY, TMP[1]);
        }
        rect[0] = minX; rect[1] = minY; rect[2] = maxX; rect[3] = maxY;
        return maxX >= 0 && minX <= sw && maxY >= 0 && minY <= sh;
    }

    public static boolean entityBox(Entity e, float tickDelta, double[] rect) {
        Vec3d p = e.getLerpedPos(tickDelta);
        Box b = e.getBoundingBox().offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ());
        return box(b, rect);
    }

    public static int width() { return sw; }
    public static int height() { return sh; }
}
