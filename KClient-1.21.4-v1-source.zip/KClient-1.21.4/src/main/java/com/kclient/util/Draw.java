package com.kclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int BG = 0x990B0D19;
    public static final int FG = 0xFFD9C8FF;
    public static final int ACCENT = 0xFF9B72FF;

    private static int tl, tr, br, sw, sh;

    private Draw() { }

    public static void hudReset(MinecraftClient mc) {
        sw = mc.getWindow().getScaledWidth();
        sh = mc.getWindow().getScaledHeight();
        tl = 6;
        tr = 6;
        br = sh - 6;
    }

    public static void topLeft(DrawContext c, int color, String... lines) {
        TextRenderer font = MinecraftClient.getInstance().textRenderer;
        int w = 0;
        for (String s : lines) w = Math.max(w, font.getWidth(s));
        int h = lines.length * 10 + 4;
        c.fill(4, tl, 4 + w + 8, tl + h, BG);
        int y = tl + 3;
        for (String s : lines) { c.drawTextWithShadow(font, s, 8, y, color); y += 10; }
        tl += h + 2;
    }

    public static void topRight(DrawContext c, int color, String line) {
        TextRenderer font = MinecraftClient.getInstance().textRenderer;
        int w = font.getWidth(line) + 8;
        c.fill(sw - w - 4, tr, sw - 4, tr + 13, BG);
        c.drawTextWithShadow(font, line, sw - w, tr + 3, color);
        tr += 15;
    }

    public static void bottomRight(DrawContext c, int color, String... lines) {
        TextRenderer font = MinecraftClient.getInstance().textRenderer;
        int w = 0;
        for (String s : lines) w = Math.max(w, font.getWidth(s));
        int h = lines.length * 10 + 4;
        int top = br - h;
        c.fill(sw - w - 12, top, sw - 4, br, BG);
        int y = top + 3;
        for (String s : lines) { c.drawTextWithShadow(font, s, sw - w - 8, y, color); y += 10; }
        br = top - 2;
    }

    public static void outline(DrawContext c, double x1, double y1, double x2, double y2, int color) {
        int a = (int) x1, b = (int) y1, d = (int) x2, e = (int) y2;
        c.fill(a, b, d, b + 1, color);
        c.fill(a, e - 1, d, e, color);
        c.fill(a, b, a + 1, e, color);
        c.fill(d - 1, b, d, e, color);
    }

    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int color) {
        double dx = x2 - x1, dy = y2 - y1;
        int steps = (int) Math.max(Math.abs(dx), Math.abs(dy));
        if (steps <= 0 || steps > 3000) return;
        double sx = dx / steps, sy = dy / steps;
        double x = x1, y = y1;
        for (int i = 0; i <= steps; i++) {
            c.fill((int) x, (int) y, (int) x + 1, (int) y + 1, color);
            x += sx; y += sy;
        }
    }

    public static void centeredText(DrawContext c, String text, double cx, double y, int color) {
        TextRenderer font = MinecraftClient.getInstance().textRenderer;
        int w = font.getWidth(text);
        int x = (int) cx - w / 2;
        c.fill(x - 2, (int) y - 1, x + w + 2, (int) y + 9, 0x88000000);
        c.drawTextWithShadow(font, text, x, (int) y, color);
    }
}
