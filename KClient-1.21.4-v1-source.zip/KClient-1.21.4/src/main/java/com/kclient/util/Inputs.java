package com.kclient.util;

import net.minecraft.client.MinecraftClient;

public final class Inputs {
    private Inputs() { }

    /** Normalised world-space {x, z} movement direction from the movement keys, or null when idle. */
    public static double[] moveDir(MinecraftClient mc) {
        float fwd = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        float left = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (fwd == 0 && left == 0) return null;
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = fwd * -sin + left * cos;
        double z = fwd * cos + left * sin;
        double len = Math.sqrt(x * x + z * z);
        return new double[] { x / len, z / len };
    }

    public static boolean moving(MinecraftClient mc) {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }
}
