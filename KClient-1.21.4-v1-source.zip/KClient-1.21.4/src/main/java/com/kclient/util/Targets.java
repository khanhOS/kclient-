package com.kclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class Targets {
    private Targets() { }

    public static boolean matches(MinecraftClient mc, Entity e, boolean players, boolean hostile, boolean passive) {
        if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive() || le instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return players && !e.isSpectator();
        if (e instanceof Monster) return hostile;
        return passive;
    }

    public static List<LivingEntity> collect(MinecraftClient mc, double range, boolean players, boolean hostile, boolean passive) {
        List<LivingEntity> out = new ArrayList<>();
        if (mc.world == null || mc.player == null) return out;
        double r2 = range * range;
        for (Entity e : mc.world.getEntities()) {
            if (!matches(mc, e, players, hostile, passive)) continue;
            if (mc.player.squaredDistanceTo(e) > r2) continue;
            out.add((LivingEntity) e);
        }
        return out;
    }

    public static LivingEntity closest(MinecraftClient mc, double range, boolean players, boolean hostile, boolean passive) {
        LivingEntity best = null;
        double bestD = range * range;
        if (mc.world == null || mc.player == null) return null;
        for (Entity e : mc.world.getEntities()) {
            if (!matches(mc, e, players, hostile, passive)) continue;
            double d = mc.player.squaredDistanceTo(e);
            if (d < bestD) { bestD = d; best = (LivingEntity) e; }
        }
        return best;
    }

    /** Returns {yaw, pitch} to look from one point towards another. */
    public static float[] rotationTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[] { yaw, pitch };
    }

    public static void face(MinecraftClient mc, Vec3d target) {
        float[] r = rotationTo(mc.player.getEyePos(), target);
        mc.player.setYaw(r[0]);
        mc.player.setPitch(Math.max(-90f, Math.min(90f, r[1])));
    }
}
