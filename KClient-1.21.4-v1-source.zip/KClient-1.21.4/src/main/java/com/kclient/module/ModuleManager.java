package com.kclient.module;

import com.kclient.module.impl.CombatModules;
import com.kclient.module.impl.HudModules;
import com.kclient.module.impl.MiscModules;
import com.kclient.module.impl.MovementModules;
import com.kclient.module.impl.PlayerModules;
import com.kclient.module.impl.RenderModules;
import com.kclient.util.Draw;
import com.kclient.util.Projector;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ModuleManager {
    static boolean dirty = true;
    private final List<Module> modules = new ArrayList<>();
    private Module[] active = new Module[0];
    private int version;

    public ModuleManager() {
        CombatModules.register(this);
        MovementModules.register(this);
        RenderModules.register(this);
        PlayerModules.register(this);
        MiscModules.register(this);
        HudModules.register(this);
    }

    public void register(Module module) { modules.add(module); }
    public List<Module> all() { return modules; }
    public int version() { refresh(); return version; }

    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    private void refresh() {
        if (!dirty) return;
        dirty = false;
        version++;
        ArrayList<Module> list = new ArrayList<>();
        for (Module m : modules) if (m.isEnabled()) list.add(m);
        active = list.toArray(new Module[0]);
    }

    public List<Module> enabledModules() {
        refresh();
        return List.of(active);
    }

    public List<Module> find(String query, Category category) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (category != Category.ALL && m.category() != category) continue;
            if (!q.isEmpty() && !m.name().toLowerCase(Locale.ROOT).contains(q)
                    && !m.description().toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(m);
        }
        return out;
    }

    public void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen == null) {
            long window = mc.getWindow().getHandle();
            for (Module m : modules) {
                if (m.bind() < 0) continue;
                boolean down = InputUtil.isKeyPressed(window, m.bind());
                if (down && !m.bindHeld) m.toggle();
                m.bindHeld = down;
            }
        }
        refresh();
        for (Module m : active) m.onTick(mc);
    }

    public void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        refresh();
        Projector.beginFrame(mc);
        Draw.hudReset(mc);
        for (Module m : active) m.onHud(context, tickDelta);
    }
}
