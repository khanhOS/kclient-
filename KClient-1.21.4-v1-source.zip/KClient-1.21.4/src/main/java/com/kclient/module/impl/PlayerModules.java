package com.kclient.module.impl;

import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.setting.NumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class PlayerModules {
    private PlayerModules() { }

    public static void register(ModuleManager m) {
        m.register(new AutoRespawn());
        m.register(new AutoEat());
        m.register(new AutoTotem());
    }

    public static final class AutoRespawn extends Module {
        public AutoRespawn() { super("AutoRespawn", "Tự hồi sinh ngay khi chết.", Category.PLAYER); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.player.isDead()) mc.player.requestRespawn();
        }
    }

    public static final class AutoEat extends Module {
        private final NumSetting hunger = num("Ngưỡng đói", 14, 1, 19, 1);
        private boolean eating;
        private int prevSlot = -1;

        public AutoEat() { super("AutoEat", "Tự ăn đồ trên thanh nhanh khi đói.", Category.PLAYER); }

        private static boolean isFood(ItemStack s) {
            if (s.isEmpty() || s.get(DataComponentTypes.FOOD) == null) return false;
            return !(s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.PUFFERFISH)
                    || s.isOf(Items.POISONOUS_POTATO) || s.isOf(Items.CHORUS_FRUIT));
        }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) return;
            boolean hungry = p.getHungerManager().getFoodLevel() <= hunger.intValue() && p.canConsume(false);
            if (eating) {
                if (!hungry || !isFood(p.getMainHandStack())) stop(mc);
                return;
            }
            if (!hungry || p.isUsingItem()) return;
            for (int i = 0; i < 9; i++) {
                if (!isFood(p.getInventory().getStack(i))) continue;
                prevSlot = p.getInventory().selectedSlot;
                p.getInventory().selectedSlot = i;
                mc.options.useKey.setPressed(true);
                eating = true;
                return;
            }
        }

        private void stop(MinecraftClient mc) {
            mc.options.useKey.setPressed(false);
            if (prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
            eating = false;
        }

        @Override
        protected void onDisable() {
            MinecraftClient mc = mc();
            if (eating && mc.player != null) stop(mc);
        }
    }

    public static final class AutoTotem extends Module {
        private final NumSetting delay = num("Độ trễ", 2, 0, 10, 1);
        private int timer;

        public AutoTotem() { super("AutoTotem", "Luôn giữ Totem bất tử ở tay phụ.", Category.PLAYER); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.interactionManager == null) return;
            if (timer > 0) { timer--; return; }
            ClientPlayerEntity p = mc.player;
            if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
            for (int i = 0; i < 36; i++) {
                if (!p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
                int slot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                timer = delay.intValue();
                return;
            }
        }
    }
}
