package com.kclient.module.impl;

import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.setting.BoolSetting;
import com.kclient.setting.EnumSetting;
import com.kclient.setting.NumSetting;
import com.kclient.util.Targets;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class CombatModules {
    private CombatModules() { }

    public static void register(ModuleManager m) {
        m.register(new AimAssist());
        m.register(new AutoClicker());
        m.register(new Reach());
        m.register(new KillAura());
        m.register(new CrystalAura());
        m.register(new BedAura());
        m.register(new TriggerBot());
        m.register(new BowAimbot());
    }

    private static void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------------ KillAura
    public static final class KillAura extends Module {
        private final EnumSetting weapon = choice("Vũ khí", "Both", "Both", "Sword", "Axe", "Any");
        private final BoolSetting autoSwitch = bool("Tự đổi vũ khí", false);
        private final BoolSetting onlyOnClick = bool("Chỉ khi bấm chuột", false);
        private final BoolSetting onlyWhenLook = bool("Chỉ khi nhìn trúng", false);
        private final EnumSetting rotate = choice("Xoay", "Always", "Always", "On Hit", "None");
        private final NumSetting hitChance = num("Tỉ lệ đánh", 100, 1, 100, 1);
        private final BoolSetting pauseOnUse = bool("Tạm dừng khi dùng đồ", true);
        private final BoolSetting players = bool("Người chơi", true);
        private final BoolSetting hostile = bool("Quái thù địch", true);
        private final BoolSetting passive = bool("Sinh vật hiền", false);
        private final NumSetting range = num("Tầm", 4.5, 1, 6, 0.1);
        private final NumSetting wallsRange = num("Tầm sau tường", 3.5, 0, 6, 0.1);
        private final EnumSetting priority = choice("Ưu tiên", "LowestHealth", "LowestHealth", "HighestHealth", "Closest");
        private final NumSetting maxTargets = num("Số mục tiêu", 1, 1, 5, 1);
        private final BoolSetting babies = bool("Con non", true);
        private final BoolSetting nametagged = bool("Có gắn tên", false);
        private final BoolSetting smartDelay = bool("Trễ thông minh", true);
        private final NumSetting hitDelay = num("Độ trễ đánh", 11, 0, 40, 1);
        private final NumSetting switchDelay = num("Độ trễ đổi", 0, 0, 10, 1);
        private int hitTimer, switchTimer;

        public KillAura() { super("KillAura", "Tự động tấn công thực thể xung quanh bạn.", Category.COMBAT); }

        private boolean weaponOk(ItemStack s) {
            return switch (weapon.get()) {
                case "Sword" -> s.isIn(ItemTags.SWORDS);
                case "Axe" -> s.isIn(ItemTags.AXES);
                case "Any" -> true;
                default -> s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES);
            };
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.interactionManager == null || mc.currentScreen != null || mc.player.isDead()) return;
            if (hitTimer > 0) hitTimer--;
            if (switchTimer > 0) { switchTimer--; return; }
            if (onlyOnClick.get() && !mc.options.attackKey.isPressed()) return;
            if (pauseOnUse.get() && mc.player.isUsingItem()) return;

            ClientPlayerEntity p = mc.player;
            if (!weaponOk(p.getMainHandStack())) {
                if (!autoSwitch.get()) return;
                int slot = -1;
                for (int i = 0; i < 9; i++) if (weaponOk(p.getInventory().getStack(i))) { slot = i; break; }
                if (slot < 0) return;
                p.getInventory().selectedSlot = slot;
                switchTimer = switchDelay.intValue();
                return;
            }

            double max = Math.max(range.value(), wallsRange.value());
            List<LivingEntity> list = new ArrayList<>();
            for (LivingEntity e : Targets.collect(mc, max, players.get(), hostile.get(), passive.get())) {
                if (!babies.get() && e.isBaby()) continue;
                if (!nametagged.get() && e.hasCustomName() && !(e instanceof PlayerEntity)) continue;
                double allowed = p.canSee(e) ? range.value() : wallsRange.value();
                if (p.distanceTo(e) > allowed) continue;
                list.add(e);
            }
            if (list.isEmpty()) return;
            Comparator<LivingEntity> cmp = switch (priority.get()) {
                case "HighestHealth" -> Comparator.comparingDouble((LivingEntity e) -> -e.getHealth());
                case "Closest" -> Comparator.comparingDouble(p::distanceTo);
                default -> Comparator.comparingDouble(LivingEntity::getHealth);
            };
            list.sort(cmp);
            LivingEntity first = list.get(0);

            if (rotate.is("Always")) Targets.face(mc, first.getBoundingBox().getCenter());

            boolean ready = smartDelay.get() ? p.getAttackCooldownProgress(0.5f) >= 1f : hitTimer <= 0;
            if (!ready) return;
            if (onlyWhenLook.get()) {
                if (!(mc.crosshairTarget instanceof EntityHitResult r) || r.getEntity() != first) return;
            }
            if (Math.random() * 100.0 > hitChance.value()) return;
            if (rotate.is("On Hit")) Targets.face(mc, first.getBoundingBox().getCenter());

            int n = Math.min(maxTargets.intValue(), list.size());
            for (int i = 0; i < n; i++) attack(mc, list.get(i));
            hitTimer = hitDelay.intValue();
        }
    }

    // ------------------------------------------------------------------ AimAssist
    public static final class AimAssist extends Module {
        private final NumSetting range = num("Tầm", 5, 1, 8, 0.5);
        private final NumSetting fov = num("Góc nhìn", 90, 10, 360, 5);
        private final NumSetting smooth = num("Độ mượt", 6, 1, 20, 1);
        private final BoolSetting players = bool("Người chơi", true);
        private final BoolSetting hostile = bool("Quái thù địch", false);
        private final BoolSetting passive = bool("Sinh vật hiền", false);
        private final BoolSetting clickOnly = bool("Chỉ khi giữ chuột", true);

        public AimAssist() { super("AimAssist", "Hỗ trợ ngắm mượt về phía mục tiêu gần.", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null) return;
            if (clickOnly.get() && !mc.options.attackKey.isPressed()) return;
            LivingEntity best = null;
            double bestDiff = fov.value() / 2.0;
            for (LivingEntity e : Targets.collect(mc, range.value(), players.get(), hostile.get(), passive.get())) {
                float[] r = Targets.rotationTo(mc.player.getEyePos(), e.getBoundingBox().getCenter());
                double diff = Math.abs(MathHelper.wrapDegrees(r[0] - mc.player.getYaw()));
                if (diff < bestDiff) { bestDiff = diff; best = e; }
            }
            if (best == null) return;
            float[] r = Targets.rotationTo(mc.player.getEyePos(), best.getBoundingBox().getCenter());
            float s = smooth.floatValue();
            mc.player.setYaw(mc.player.getYaw() + MathHelper.wrapDegrees(r[0] - mc.player.getYaw()) / s);
            mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + (r[1] - mc.player.getPitch()) / s, -90f, 90f));
        }
    }

    // ------------------------------------------------------------------ AutoClicker
    public static final class AutoClicker extends Module {
        private final NumSetting cps = num("CPS", 12, 1, 20, 1);
        private final BoolSetting respectCooldown = bool("Chờ hồi chiêu", true);
        private double acc;

        public AutoClicker() { super("AutoClicker", "Tự đánh vào thực thể bạn ngắm khi giữ chuột đánh.", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (!mc.options.attackKey.isPressed()) { acc = 0; return; }
            acc = Math.min(2.0, acc + cps.value() / 20.0);
            if (acc < 1.0) return;
            if (!(mc.crosshairTarget instanceof EntityHitResult r)) return;
            if (respectCooldown.get() && mc.player.getAttackCooldownProgress(0.5f) < 0.9f) return;
            acc -= 1.0;
            attack(mc, r.getEntity());
        }
    }

    // ------------------------------------------------------------------ Reach
    public static final class Reach extends Module {
        private final NumSetting reach = num("Tầm với", 4.5, 3, 6, 0.1);

        public Reach() { super("Reach", "Tăng tầm tương tác với thực thể (server phải cho phép).", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a != null && a.getBaseValue() != reach.value()) a.setBaseValue(reach.value());
        }

        @Override
        protected void onDisable() {
            MinecraftClient mc = mc();
            if (mc.player == null) return;
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a != null) a.setBaseValue(3.0);
        }
    }

    // ------------------------------------------------------------------ TriggerBot
    public static final class TriggerBot extends Module {
        private final BoolSetting players = bool("Người chơi", true);
        private final BoolSetting hostile = bool("Quái thù địch", true);
        private final BoolSetting passive = bool("Sinh vật hiền", false);
        private final BoolSetting weaponOnly = bool("Chỉ khi cầm vũ khí", false);

        public TriggerBot() { super("TriggerBot", "Tự đánh khi tâm ngắm trúng mục tiêu.", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (!(mc.crosshairTarget instanceof EntityHitResult r)) return;
            if (!Targets.matches(mc, r.getEntity(), players.get(), hostile.get(), passive.get())) return;
            if (weaponOnly.get() && !(mc.player.getMainHandStack().isIn(ItemTags.SWORDS) || mc.player.getMainHandStack().isIn(ItemTags.AXES))) return;
            if (mc.player.getAttackCooldownProgress(0.5f) < 1f) return;
            attack(mc, r.getEntity());
        }
    }

    // ------------------------------------------------------------------ BowAimbot
    public static final class BowAimbot extends Module {
        private final NumSetting range = num("Tầm", 60, 10, 100, 5);
        private final BoolSetting players = bool("Người chơi", true);
        private final BoolSetting hostile = bool("Quái thù địch", true);
        private final BoolSetting passive = bool("Sinh vật hiền", false);
        private final BoolSetting predict = bool("Dự đoán di chuyển", true);

        public BowAimbot() { super("BowAimbot", "Tự ngắm cung vào mục tiêu gần nhất (bù trọng lực).", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (!p.isUsingItem() || !p.getActiveItem().isOf(Items.BOW)) return;
            float pull = BowItem.getPullProgress(p.getItemUseTime());
            if (pull < 0.1f) return;
            LivingEntity t = Targets.closest(mc, range.value(), players.get(), hostile.get(), passive.get());
            if (t == null) return;
            double v = pull * 3.0, g = 0.05;
            Vec3d eye = p.getEyePos();
            Vec3d aim = t.getBoundingBox().getCenter();
            if (predict.get()) {
                double ticks = eye.distanceTo(aim) / Math.max(0.5, v);
                aim = aim.add((t.getX() - t.prevX) * ticks, 0, (t.getZ() - t.prevZ) * ticks);
            }
            double dx = aim.x - eye.x, dz = aim.z - eye.z, dy = aim.y - eye.y;
            double x = Math.sqrt(dx * dx + dz * dz);
            double disc = v * v * v * v - g * (g * x * x + 2 * dy * v * v);
            if (disc < 0 || x < 0.01) return;
            double pitch = -Math.toDegrees(Math.atan((v * v - Math.sqrt(disc)) / (g * x)));
            p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
            p.setPitch((float) MathHelper.clamp(pitch, -90, 90));
        }
    }

    // ------------------------------------------------------------------ CrystalAura (lite)
    public static final class CrystalAura extends Module {
        private final NumSetting breakRange = num("Tầm phá", 4.5, 1, 6, 0.1);
        private final NumSetting placeRange = num("Tầm đặt", 4.5, 1, 6, 0.1);
        private final NumSetting targetRange = num("Tầm mục tiêu", 8, 2, 12, 1);
        private final NumSetting delay = num("Độ trễ", 2, 0, 10, 1);
        private final BoolSetting place = bool("Tự đặt", true);
        private final BoolSetting rotate = bool("Xoay", true);
        private int timer;

        public CrystalAura() { super("CrystalAura", "Phá pha lê End và đặt pha lê cạnh người chơi gần nhất.", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (timer > 0) { timer--; return; }
            ClientPlayerEntity p = mc.player;

            EndCrystalEntity crystal = null;
            double bd = breakRange.value() * breakRange.value();
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof EndCrystalEntity c && p.squaredDistanceTo(c) <= bd) { crystal = c; bd = p.squaredDistanceTo(c); }
            }
            if (crystal != null) {
                if (rotate.get()) Targets.face(mc, crystal.getPos());
                attack(mc, crystal);
                timer = delay.intValue();
                return;
            }
            if (!place.get()) return;
            Hand hand = p.getMainHandStack().isOf(Items.END_CRYSTAL) ? Hand.MAIN_HAND
                    : p.getOffHandStack().isOf(Items.END_CRYSTAL) ? Hand.OFF_HAND : null;
            if (hand == null) return;
            LivingEntity target = Targets.closest(mc, targetRange.value(), true, false, false);
            if (target == null) return;

            BlockPos tp = target.getBlockPos();
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            double pr = placeRange.value() * placeRange.value();
            BlockPos.Mutable pos = new BlockPos.Mutable();
            for (int x = -3; x <= 3; x++) for (int y = -2; y <= 1; y++) for (int z = -3; z <= 3; z++) {
                pos.set(tp.getX() + x, tp.getY() + y, tp.getZ() + z);
                var state = mc.world.getBlockState(pos);
                if (!state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK)) continue;
                if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) > pr) continue;
                if (!mc.world.getBlockState(pos.up()).isAir() || !mc.world.getBlockState(pos.up(2)).isAir()) continue;
                if (!mc.world.getOtherEntities(null, new Box(pos.up()).stretch(0, 1, 0)).isEmpty()) continue;
                double d = target.squaredDistanceTo(Vec3d.ofCenter(pos));
                if (d < bestD) { bestD = d; best = pos.toImmutable(); }
            }
            if (best == null) return;
            if (rotate.get()) Targets.face(mc, Vec3d.ofCenter(best).add(0, 0.5, 0));
            BlockHitResult hit = new BlockHitResult(new Vec3d(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5), Direction.UP, best, false);
            mc.interactionManager.interactBlock(p, hand, hit);
            p.swingHand(hand);
            timer = delay.intValue();
        }
    }

    // ------------------------------------------------------------------ BedAura (lite)
    public static final class BedAura extends Module {
        private final NumSetting range = num("Tầm", 4.5, 1, 6, 0.1);
        private final NumSetting targetRange = num("Tầm mục tiêu", 6, 2, 12, 1);
        private final NumSetting delay = num("Độ trễ", 5, 1, 20, 1);
        private int timer;

        public BedAura() { super("BedAura", "Kích nổ giường gần đó (Nether/End) khi có kẻ địch lại gần.", Category.COMBAT); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (timer > 0) { timer--; return; }
            if (mc.world.getDimension().bedWorks()) return;
            if (Targets.closest(mc, targetRange.value(), true, false, false) == null) return;
            ClientPlayerEntity p = mc.player;
            BlockPos base = p.getBlockPos();
            int r = (int) Math.ceil(range.value());
            double r2 = range.value() * range.value();
            BlockPos.Mutable pos = new BlockPos.Mutable();
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                pos.set(base.getX() + x, base.getY() + y, base.getZ() + z);
                if (!(mc.world.getBlockState(pos).getBlock() instanceof BedBlock)) continue;
                if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) > r2) continue;
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos.toImmutable(), false);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                p.swingHand(Hand.MAIN_HAND);
                timer = delay.intValue();
                return;
            }
        }
    }
}
