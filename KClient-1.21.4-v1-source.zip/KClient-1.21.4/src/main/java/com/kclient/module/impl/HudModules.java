package com.kclient.module.impl;

import com.kclient.KClient;
import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.util.Draw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class HudModules {
    private HudModules() { }

    public static void register(ModuleManager m) {
        m.register(new Watermark());
        m.register(new Coordinates());
        m.register(new DirectionHud());
        m.register(new Fps());
        m.register(new Ping());
        m.register(new ArrayListHud());
        m.register(new ArmorHud());
        m.register(new ServerHud());
    }

    public static final class Watermark extends Module {
        public Watermark() { super("Watermark", "Hiện tên KClient.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) { Draw.topLeft(c, Draw.ACCENT, "KClient 1.21.4"); }
    }

    public static final class Coordinates extends Module {
        public Coordinates() { super("Coordinates", "Hiện tọa độ XYZ.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) {
            var p = mc().player;
            Draw.topLeft(c, Draw.FG,
                    String.format(Locale.ROOT, "X: %.1f", p.getX()),
                    String.format(Locale.ROOT, "Y: %.1f", p.getY()),
                    String.format(Locale.ROOT, "Z: %.1f", p.getZ()));
        }
    }

    public static final class DirectionHud extends Module {
        public DirectionHud() { super("Direction", "Hiện hướng bạn đang nhìn.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) {
            Direction d = mc().player.getHorizontalFacing();
            String s = switch (d) {
                case NORTH -> "Bắc (-Z)";
                case SOUTH -> "Nam (+Z)";
                case EAST -> "Đông (+X)";
                default -> "Tây (-X)";
            };
            Draw.topLeft(c, Draw.FG, s);
        }
    }

    public static final class Fps extends Module {
        public Fps() { super("FPS", "Hiện số khung hình/giây.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) { Draw.topRight(c, Draw.FG, "FPS: " + mc().getCurrentFps()); }
    }

    public static final class Ping extends Module {
        public Ping() { super("Ping", "Hiện độ trễ tới server.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) {
            MinecraftClient mc = mc();
            if (mc.getNetworkHandler() == null) return;
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) Draw.topRight(c, Draw.FG, "Ping: " + e.getLatency() + "ms");
        }
    }

    public static final class ArrayListHud extends Module {
        private List<Module> sorted = new ArrayList<>();
        private int version = -1;

        public ArrayListHud() { super("ArrayList", "Liệt kê các module đang bật.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) {
            int v = KClient.MODULES.version();
            if (v != version) {
                version = v;
                var font = mc().textRenderer;
                sorted = new ArrayList<>(KClient.MODULES.enabledModules());
                sorted.removeIf(m -> m.category() == Category.HUD);
                sorted.sort(Comparator.comparingInt((Module m) -> font.getWidth(m.name())).reversed());
            }
            for (Module m : sorted) Draw.topRight(c, Draw.FG, m.name());
        }
    }

    public static final class ArmorHud extends Module {
        public ArmorHud() { super("ArmorHUD", "Hiện giáp phía trên thanh nhanh.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) {
            MinecraftClient mc = mc();
            int x = mc.getWindow().getScaledWidth() / 2 - 36;
            int y = mc.getWindow().getScaledHeight() - 72;
            EquipmentSlot[] slots = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
            for (EquipmentSlot s : slots) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (!st.isEmpty()) {
                    c.drawItem(st, x, y);
                    c.drawStackOverlay(mc.textRenderer, st, x, y);
                }
                x += 18;
            }
        }
    }

    public static final class ServerHud extends Module {
        public ServerHud() { super("ServerInfo", "Hiện địa chỉ server và số người chơi.", Category.HUD); }

        @Override
        public void onHud(DrawContext c, float td) {
            MinecraftClient mc = mc();
            ServerInfo info = mc.getCurrentServerEntry();
            String addr = info != null ? info.address : "Chơi đơn";
            int players = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerList().size() : 1;
            Draw.bottomRight(c, Draw.FG, "Máy chủ: " + addr, "Người chơi: " + players);
        }
    }
}
