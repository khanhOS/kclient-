package com.kclient.module;

import com.kclient.setting.BoolSetting;
import com.kclient.setting.EnumSetting;
import com.kclient.setting.NumSetting;
import com.kclient.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String id;
    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    private int bind = -1;
    boolean bindHeld;

    protected Module(String name, String description, Category category) {
        this.id = name.toLowerCase().replaceAll("[^a-z0-9]", "");
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public final String id() { return id; }
    public final String name() { return name; }
    public final String description() { return description; }
    public final Category category() { return category; }
    public final boolean isEnabled() { return enabled; }
    public final List<Setting> settings() { return settings; }
    public final int bind() { return bind; }
    public final void setBind(int key) { bind = key; }

    public final void toggle() { setEnabled(!enabled); }

    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        ModuleManager.dirty = true;
        if (enabled) onEnable(); else onDisable();
    }

    protected final BoolSetting bool(String n, boolean def) {
        BoolSetting s = new BoolSetting(n, def);
        settings.add(s);
        return s;
    }

    protected final NumSetting num(String n, double def, double min, double max, double step) {
        NumSetting s = new NumSetting(n, def, min, max, step);
        settings.add(s);
        return s;
    }

    protected final EnumSetting choice(String n, String def, String... options) {
        EnumSetting s = new EnumSetting(n, def, options);
        settings.add(s);
        return s;
    }

    protected static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    protected void onEnable() { }
    protected void onDisable() { }
    public void onTick(MinecraftClient mc) { }
    public void onHud(DrawContext context, float tickDelta) { }
}
