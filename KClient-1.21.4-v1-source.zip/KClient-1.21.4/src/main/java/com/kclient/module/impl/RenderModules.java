package com.kclient.module.impl;

import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.setting.BoolSetting;
import com.kclient.setting.EnumSetting;
import com.kclient.setting.NumSetting;
import com.kclient.util.Draw;
import com.kclient.util.Projector;
import com.kclient.util.Targets;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

public final class RenderModules {
    private RenderModules() { }

    public static void register(ModuleManager m) {
        m.register(new Esp("ESP", "Vẽ khung quanh sinh vật xuyên tường.", 0));
        m.register(new Tracers());
        m.register(new StorageEsp());
        m.register(new NameTags());
        m.register(new Esp("BoxESP", "Hộp tô màu quanh sinh vật.", 1));
        m.register(new Esp("PlayerESP", "Khung và thanh máu chỉ cho người chơi.", 2));
        m.register(new ItemEsp());
        m.register(new Fullbright());
    }

    static int colorOf(Entity e) {
        if (e instanceof PlayerEntity) return 0xFFB388FF;
        if (e instanceof Monster) return 0xFFFF5555;
        return 0xFF55FF55;
    }

    abstract static class LivingBase extends Module {
        final BoolSetting players = bool("Người chơi", true);
        final BoolSetting hostile = bool("Quái thù địch", true);
        final BoolSetting passive = bool("Sinh vật hiền", true);
        final NumSetting range = num("Tầm", 64, 8, 256, 8);
        private final double[] rect = new double[4];

        LivingBase(String name, String desc) { super(name, desc, Category.RENDER); }

        @Override
        public final void onHud(DrawContext ctx, float td) {
            MinecraftClient mc = mc();
            double r2 = range.value() * range.value();
            for (Entity e : mc.world.getEntities()) {
                if (!Targets.matches(mc, e, players.get(), hostile.get(), passive.get())) continue;
                if (mc.player.squaredDistanceTo(e) > r2) continue;
                draw(ctx, (LivingEntity) e, td, rect);
            }
        }

        abstract void draw(DrawContext ctx, LivingEntity e, float td, double[] rect);
    }

    /** style 0 = outline, 1 = filled box, 2 = player outline + health bar. */
    static final class Esp extends LivingBase {
        private final int style;

        Esp(String name, String desc, int style) {
            super(name, desc);
            this.style = style;
            if (style == 2) { hostile.set(false); passive.set(false); }
        }

        @Override
        void draw(DrawContext ctx, LivingEntity e, float td, double[] r) {
            if (!Projector.entityBox(e, td, r)) return;
            int c = colorOf(e);
            if (style == 1) ctx.fill((int) r[0], (int) r[1], (int) r[2], (int) r[3], (c & 0x00FFFFFF) | 0x30000000);
            Draw.outline(ctx, r[0], r[1], r[2], r[3], c);
            if (style == 2) {
                float f = Math.max(0f, Math.min(1f, e.getHealth() / e.getMaxHealth()));
                int top = (int) r[1], bottom = (int) r[3];
                int x = (int) r[0] - 4;
                ctx.fill(x, top, x + 2, bottom, 0xAA000000);
                int h = (int) ((bottom - top) * f);
                ctx.fill(x, bottom - h, x + 2, bottom, f > 0.5f ? 0xFF55FF55 : f > 0.25f ? 0xFFFFAA00 : 0xFFFF5555);
            }
        }
    }

    static final class Tracers extends LivingBase {
        private final EnumSetting origin = choice("Điểm bắt đầu", "Bottom", "Bottom", "Center");

        Tracers() {
            super("Tracers", "Vẽ đường nối từ màn hình tới thực thể.");
            hostile.set(false);
            passive.set(false);
        }

        @Override
        void draw(DrawContext ctx, LivingEntity e, float td, double[] r) {
            if (!Projector.entityBox(e, td, r)) return;
            double ox = Projector.width() / 2.0;
            double oy = origin.is("Center") ? Projector.height() / 2.0 : Projector.height();
            Draw.line(ctx, ox, oy, (r[0] + r[2]) / 2.0, r[3], colorOf(e));
        }
    }

    static final class NameTags extends LivingBase {
        private final BoolSetting health = bool("Máu", true);
        private final double[] p = new double[2];

        NameTags() {
            super("NameTags", "Hiện tên và máu rõ ràng phía trên thực thể.");
            hostile.set(false);
            passive.set(false);
        }

        @Override
        void draw(DrawContext ctx, LivingEntity e, float td, double[] r) {
            Vec3d pos = e.getLerpedPos(td);
            if (!Projector.project(pos.x, pos.y + e.getHeight() + 0.45, pos.z, p)) return;
            String text = e.getName().getString();
            if (health.get()) text += " " + (int) Math.ceil(e.getHealth());
            Draw.centeredText(ctx, text, p[0], p[1] - 10, colorOf(e));
        }
    }

    static final class ItemEsp extends Module {
        private final NumSetting range = num("Tầm", 48, 8, 128, 8);
        private final double[] r = new double[4];

        ItemEsp() { super("ItemESP", "Làm nổi bật vật phẩm rơi trên đất.", Category.RENDER); }

        @Override
        public void onHud(DrawContext ctx, float td) {
            MinecraftClient mc = mc();
            double r2 = range.value() * range.value();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof ItemEntity item) || mc.player.squaredDistanceTo(e) > r2) continue;
                if (!Projector.entityBox(e, td, r)) continue;
                Draw.outline(ctx, r[0] - 1, r[1] - 1, r[2] + 1, r[3] + 1, 0xFFFFD84D);
                Draw.centeredText(ctx, item.getStack().getName().getString() + " x" + item.getStack().getCount(),
                        (r[0] + r[2]) / 2.0, r[1] - 11, 0xFFFFD84D);
            }
        }
    }

    static final class StorageEsp extends Module {
        private record Entry(Box box, int color) { }

        private final NumSetting chunks = num("Số chunk", 3, 1, 8, 1);
        private final List<Entry> cache = new ArrayList<>();
        private final double[] r = new double[4];
        private int tick;

        StorageEsp() { super("StorageESP", "Làm nổi bật rương, thùng và hộp shulker.", Category.RENDER); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (tick++ % 10 != 0) return;
            cache.clear();
            int cx = mc.player.getBlockX() >> 4, cz = mc.player.getBlockZ() >> 4;
            int n = chunks.intValue();
            for (int x = -n; x <= n; x++) for (int z = -n; z <= n; z++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx + x, cz + z);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    int color;
                    if (be instanceof EnderChestBlockEntity) color = 0xFFAA55FF;
                    else if (be instanceof ChestBlockEntity) color = 0xFFFFAA00;
                    else if (be instanceof BarrelBlockEntity) color = 0xFFC0803A;
                    else if (be instanceof ShulkerBoxBlockEntity) color = 0xFFFF77FF;
                    else continue;
                    cache.add(new Entry(new Box(be.getPos()), color));
                }
            }
        }

        @Override
        public void onHud(DrawContext ctx, float td) {
            for (Entry e : cache) if (Projector.box(e.box(), r)) Draw.outline(ctx, r[0], r[1], r[2], r[3], e.color());
        }

        @Override
        protected void onDisable() { cache.clear(); }
    }

    static final class Fullbright extends Module {
        Fullbright() { super("Fullbright", "Sáng tối đa bằng hiệu ứng nhìn đêm ẩn.", Category.RENDER); }

        @Override
        public void onTick(MinecraftClient mc) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 300) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            }
        }

        @Override
        protected void onDisable() {
            MinecraftClient mc = mc();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
