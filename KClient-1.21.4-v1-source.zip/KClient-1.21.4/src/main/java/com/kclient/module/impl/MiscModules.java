package com.kclient.module.impl;

import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.mixin.MinecraftClientAccessor;
import com.kclient.setting.BoolSetting;
import com.kclient.setting.EnumSetting;
import com.kclient.setting.NumSetting;
import com.kclient.util.Draw;
import com.kclient.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MiscModules {
    private MiscModules() { }

    public static void register(ModuleManager m) {
        m.register(new AutoGG());
        m.register(new ChatSpam());
        m.register(new AntiAFK());
        m.register(new XRay());
        m.register(new AutoTool());
        m.register(new FastPlace());
        m.register(new InventoryMove());
    }

    public static final class AutoGG extends Module {
        private final EnumSetting message = choice("Tin nhắn", "gg", "gg", "good game", "gg ez");
        private long last;

        public AutoGG() { super("AutoGG", "Tự nhắn tin khi chat thông báo người thắng.", Category.MISC); }

        public void onMessage(String text) {
            if (!isEnabled()) return;
            String t = text.toLowerCase(Locale.ROOT);
            if (!(t.contains("has won") || t.contains("winner") || t.contains("victory"))) return;
            long now = System.currentTimeMillis();
            if (now - last < 10_000) return;
            last = now;
            MinecraftClient mc = mc();
            if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatMessage(message.get());
        }
    }

    public static final class ChatSpam extends Module {
        private final EnumSetting message = choice("Tin nhắn", "KClient on top", "KClient on top", "gg", "ez", "Free KClient");
        private final NumSetting interval = num("Chu kỳ (giây)", 8, 2, 60, 1);
        private int timer;

        public ChatSpam() { super("ChatSpam", "Gửi tin nhắn có sẵn theo chu kỳ.", Category.MISC); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (++timer < interval.intValue() * 20) return;
            timer = 0;
            if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatMessage(message.get());
        }
    }

    public static final class AntiAFK extends Module {
        private int timer;

        public AntiAFK() { super("AntiAFK", "Vung tay và xoay nhẹ để tránh bị kick AFK.", Category.MISC); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (++timer < 300) return;
            timer = 0;
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.setYaw(mc.player.getYaw() + (Math.random() < 0.5 ? -4f : 4f));
        }
    }

    public static final class XRay extends Module {
        private record Ore(BlockPos pos, int color) { }

        private static final Map<Block, Integer> ORES = new HashMap<>();
        static {
            put(0xFF55FFFF, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
            put(0xFF55FF55, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
            put(0xFFFFD84D, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
            put(0xFFD8AF93, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
            put(0xFFFF5555, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
            put(0xFF5577FF, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
            put(0xFFFF9955, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
            put(0xFFAAAAAA, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
            put(0xFFB5651D, Blocks.ANCIENT_DEBRIS);
            put(0xFFFFFFFF, Blocks.NETHER_QUARTZ_ORE);
        }

        private static void put(int color, Block... blocks) { for (Block b : blocks) ORES.put(b, color); }

        private final NumSetting radius = num("Bán kính", 14, 4, 24, 2);
        private final BoolSetting coal = bool("Than", false);
        private final List<Ore> found = new ArrayList<>();
        private final double[] r = new double[4];
        private int tick;

        public XRay() { super("XRay", "Đánh dấu quặng gần đó xuyên tường (overlay, không đổi texture).", Category.MISC); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (tick++ % 20 != 0) return;
            found.clear();
            BlockPos c = mc.player.getBlockPos();
            int rad = radius.intValue();
            BlockPos.Mutable pos = new BlockPos.Mutable();
            for (int x = -rad; x <= rad; x++) for (int y = -rad; y <= rad; y++) for (int z = -rad; z <= rad; z++) {
                pos.set(c.getX() + x, c.getY() + y, c.getZ() + z);
                BlockState s = mc.world.getBlockState(pos);
                if (s.isAir()) continue;
                Integer color = ORES.get(s.getBlock());
                if (color == null || (!coal.get() && (s.isOf(Blocks.COAL_ORE) || s.isOf(Blocks.DEEPSLATE_COAL_ORE)))) continue;
                found.add(new Ore(pos.toImmutable(), color));
                if (found.size() >= 400) return;
            }
        }

        @Override
        public void onHud(DrawContext ctx, float td) {
            for (Ore o : found) if (Projector.box(new Box(o.pos()), r)) Draw.outline(ctx, r[0], r[1], r[2], r[3], o.color());
        }

        @Override
        protected void onDisable() { found.clear(); }
    }

    public static final class AutoTool extends Module {
        private int prevSlot = -1;

        public AutoTool() { super("AutoTool", "Tự chọn công cụ đào nhanh nhất.", Category.MISC); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null) return;
            if (mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof BlockHitResult hit
                    && hit.getType() == HitResult.Type.BLOCK) {
                BlockState state = mc.world.getBlockState(hit.getBlockPos());
                int cur = mc.player.getInventory().selectedSlot;
                int best = cur;
                float bestSpeed = mc.player.getInventory().getStack(cur).getMiningSpeedMultiplier(state);
                for (int i = 0; i < 9; i++) {
                    float sp = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(state);
                    if (sp > bestSpeed) { bestSpeed = sp; best = i; }
                }
                if (best != cur) {
                    if (prevSlot < 0) prevSlot = cur;
                    mc.player.getInventory().selectedSlot = best;
                }
            } else if (prevSlot >= 0) {
                mc.player.getInventory().selectedSlot = prevSlot;
                prevSlot = -1;
            }
        }
    }

    public static final class FastPlace extends Module {
        public FastPlace() { super("FastPlace", "Bỏ độ trễ khi đặt khối/vật phẩm.", Category.MISC); }

        @Override
        public void onTick(MinecraftClient mc) {
            ((MinecraftClientAccessor) mc).kclient$setItemUseCooldown(0);
        }
    }

    public static final class InventoryMove extends Module {
        public InventoryMove() { super("InventoryMove", "Đi được khi đang mở túi đồ/menu.", Category.MISC); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen
                    || mc.currentScreen instanceof com.kclient.gui.ClickGuiScreen) return;
            long window = mc.getWindow().getHandle();
            var keys = new net.minecraft.client.option.KeyBinding[] {
                    mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey,
                    mc.options.jumpKey, mc.options.sprintKey };
            for (var k : keys) {
                int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
                k.setPressed(InputUtil.isKeyPressed(window, code));
            }
        }
    }
}
