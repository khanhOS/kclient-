package com.kclient.module;

public enum Category {
    ALL("Tất cả"),
    COMBAT("Chiến đấu"),
    MOVEMENT("Di chuyển"),
    RENDER("Hiển thị"),
    PLAYER("Người chơi"),
    MISC("Khác"),
    HUD("HUD"),
    CONFIG("Cấu hình");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}
