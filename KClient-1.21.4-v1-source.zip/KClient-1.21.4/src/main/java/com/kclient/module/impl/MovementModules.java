package com.kclient.module.impl;

import com.kclient.module.Category;
import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.setting.BoolSetting;
import com.kclient.setting.NumSetting;
import com.kclient.util.Inputs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public final class MovementModules {
    private MovementModules() { }

    public static void register(ModuleManager m) {
        m.register(new Sprint());
        m.register(new Strafe());
        m.register(new AutoJump());
        m.register(new Flight());
        m.register(new Jesus());
        m.register(new LongJump());
        m.register(new Speed());
    }

    public static final class Sprint extends Module {
        private final BoolSetting omni = bool("Mọi hướng", false);

        public Sprint() { super("Sprint", "Tự chạy nhanh khi bạn di chuyển.", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.getHungerManager().getFoodLevel() <= 6 || p.isSneaking() || p.horizontalCollision) return;
            boolean go = omni.get() ? Inputs.moving(mc) : mc.options.forwardKey.isPressed();
            if (go) p.setSprinting(true);
        }
    }

    public static final class Strafe extends Module {
        public Strafe() { super("Strafe", "Giữ tốc độ khi đổi hướng trên không.", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
            double[] d = Inputs.moveDir(mc);
            if (d == null) return;
            Vec3d v = p.getVelocity();
            double speed = Math.sqrt(v.x * v.x + v.z * v.z);
            if (speed < 0.05) return;
            p.setVelocity(d[0] * speed, v.y, d[1] * speed);
        }
    }

    public static final class AutoJump extends Module {
        public AutoJump() { super("AutoJump", "Tự nhảy khi đi vào khối.", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.isOnGround() && p.horizontalCollision && Inputs.moving(mc) && !p.isSneaking()) {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, 0.42, v.z);
            }
        }
    }

    public static final class Flight extends Module {
        private final NumSetting speed = num("Tốc độ", 2.0, 0.5, 6.0, 0.5);

        public Flight() { super("Flight", "Bay như chế độ Creative (server phải cho phép).", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            PlayerAbilities a = mc.player.getAbilities();
            a.allowFlying = true;
            a.flying = true;
            a.setFlySpeed(speed.floatValue() * 0.05f);
        }

        @Override
        protected void onDisable() {
            MinecraftClient mc = mc();
            if (mc.player == null) return;
            PlayerAbilities a = mc.player.getAbilities();
            boolean keep = mc.player.isCreative() || mc.player.isSpectator();
            a.allowFlying = keep;
            if (!keep) a.flying = false;
            a.setFlySpeed(0.05f);
        }
    }

    public static final class Jesus extends Module {
        public Jesus() { super("Jesus", "Đi trên mặt nước.", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.isSneaking() || mc.options.jumpKey.isPressed()) return;
            BlockPos feet = BlockPos.ofFloored(p.getX(), p.getY() + 0.05, p.getZ());
            boolean inWater = mc.world.getFluidState(feet).isIn(FluidTags.WATER);
            boolean above = mc.world.getFluidState(feet.up()).isIn(FluidTags.WATER);
            Vec3d v = p.getVelocity();
            if (inWater && above) p.setVelocity(v.x, 0.12, v.z);
            else if (inWater) p.setVelocity(v.x, 0.0, v.z);
        }
    }

    public static final class LongJump extends Module {
        private final NumSetting boost = num("Tăng tốc", 1.6, 1.0, 3.0, 0.1);
        private boolean boosted;

        public LongJump() { super("LongJump", "Tăng tốc ngang một lần mỗi cú nhảy.", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.isOnGround()) { boosted = false; return; }
            if (boosted || p.getVelocity().y < 0.3) return;
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x * boost.value(), v.y, v.z * boost.value());
            boosted = true;
        }
    }

    public static final class Speed extends Module {
        private final NumSetting speed = num("Tốc độ", 1.4, 1.0, 4.0, 0.1);

        public Speed() { super("Speed", "Di chuyển nhanh hơn trên mặt đất và trên không.", Category.MOVEMENT); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.getAbilities().flying) return;
            double[] d = Inputs.moveDir(mc);
            if (d == null) return;
            double s = 0.28 * speed.value();
            Vec3d v = p.getVelocity();
            p.setVelocity(d[0] * s, v.y, d[1] * s);
        }
    }
}
