package com.kclient.config;

import com.kclient.module.Module;
import com.kclient.module.ModuleManager;
import com.kclient.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class ConfigManager {
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("kclient.properties");

    public void load(ModuleManager manager) {
        if (!Files.isRegularFile(file)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
        } catch (IOException e) {
            System.err.println("[KClient] Could not load config: " + e.getMessage());
            return;
        }
        for (Module m : manager.all()) {
            for (Setting s : m.settings()) {
                String v = p.getProperty("m." + m.id() + ".s." + s.id);
                if (v != null) s.deserialize(v);
            }
            String bind = p.getProperty("m." + m.id() + ".bind");
            if (bind != null) {
                try { m.setBind(Integer.parseInt(bind)); } catch (NumberFormatException ignored) { }
            }
            String en = p.getProperty("m." + m.id() + ".enabled");
            if (en != null) m.setEnabled(Boolean.parseBoolean(en));
        }
    }

    public void save(ModuleManager manager) {
        Properties p = new Properties();
        for (Module m : manager.all()) {
            p.setProperty("m." + m.id() + ".enabled", Boolean.toString(m.isEnabled()));
            p.setProperty("m." + m.id() + ".bind", Integer.toString(m.bind()));
            for (Setting s : m.settings()) p.setProperty("m." + m.id() + ".s." + s.id, s.serialize());
        }
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                p.store(out, "KClient settings (local only)");
            }
        } catch (IOException e) {
            System.err.println("[KClient] Could not save config: " + e.getMessage());
        }
    }
}
